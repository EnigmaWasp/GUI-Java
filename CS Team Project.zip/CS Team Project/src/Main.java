import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Main extends Application {

	@SuppressWarnings("unused")
	@Override
	public void start(Stage primaryStage) {

		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));

		int row = 0;
		if (false) {

			Text step1of2 = new Text("Step 1 of 2 - Referees list update");
			grid.add(step1of2, 0, row, 3, 1);

			Button nextStepButton = new Button();
			nextStepButton.setText("Next Step");
			grid.add(nextStepButton, 3, row, 1, 1);

			Button exitButton = new Button();
			exitButton.setText("Exit");
			grid.add(exitButton, 4, row, 1, 1);

			row++;

			Text filterApplied = new Text("Filter not applied");
			grid.add(filterApplied, 0, row, 1, 1);

			Button clearFilter = new Button();
			clearFilter.setText("Clear filter");
			grid.add(clearFilter, 1, row, 1, 1);

			row++;

			TextArea textArea = new TextArea();
			grid.add(textArea, 0, row, 5, 5);

			row += 5;

			Text idText = new Text("ID");
			grid.add(idText, 0, row, 1, 1);

			Text firstNameText = new Text("First name");
			grid.add(firstNameText, 1, row, 1, 1);

			Text lastNameText = new Text("Last name");
			grid.add(lastNameText, 2, row, 1, 1);

			Text allocationsText = new Text("Allocations");
			grid.add(allocationsText, 3, row, 1, 1);

			row++;

			TextField idEdit = new TextField();
			grid.add(idEdit, 0, row, 1, 1);

			TextField firstNameEdit = new TextField();
			grid.add(firstNameEdit, 1, row, 1, 1);

			TextField lastNameEdit = new TextField();
			grid.add(lastNameEdit, 2, row, 1, 1);

			TextField allocationsEdit = new TextField();
			grid.add(allocationsEdit, 3, row, 1, 1);

			row++;

			Text qualificationText = new Text("Qualification");
			grid.add(qualificationText, 0, row, 1, 1);

			Text homeAreaText = new Text("Home area");
			grid.add(homeAreaText, 1, row, 1, 1);

			Text travelsToText = new Text("Travels to");
			grid.add(travelsToText, 2, row, 1, 1);

			row++;

			ChoiceBox<String> qualificationList = new ChoiceBox<>();
			qualificationList.getItems().addAll("NJB1", "NJB2", "NJB3", "NJB4",
					"IJB1", "IJB2", "IJB3", "IJB4");
			grid.add(qualificationList, 0, row, 1, 1);

			ChoiceBox<String> homeAreaList = new ChoiceBox<>();
			homeAreaList.getItems().addAll("North", "Central", "South");
			grid.add(homeAreaList, 1, row, 1, 1);

			ChoiceBox<String> travelsToList = new ChoiceBox<>();
			travelsToList.getItems().addAll("YNN", "NYN", "NNY", "YYN", "YNY",
					"NYY", "YYY");
			grid.add(travelsToList, 2, row, 1, 1);

			Button filterButton = new Button();
			filterButton.setText("Filter");
			grid.add(filterButton, 3, row, 1, 1);

			row++;

			Button showDetailsButton = new Button();
			showDetailsButton.setText("Show details");
			grid.add(showDetailsButton, 0, row, 1, 1);

			Button updateDetailsButton = new Button();
			updateDetailsButton.setText("Update details");
			grid.add(updateDetailsButton, 1, row, 1, 1);

			Button deleteRefereeButton = new Button();
			deleteRefereeButton.setText("Delete Referee");
			grid.add(deleteRefereeButton, 2, row, 1, 1);

			Button addRefereeButton = new Button();
			addRefereeButton.setText("Add referee");
			grid.add(addRefereeButton, 3, row, 1, 1);

			Button showBarChartButton = new Button();
			showBarChartButton.setText("Show bar chart");
			grid.add(showBarChartButton, 4, row, 1, 1);

			row++;

			Text statusText = new Text("Status");
			grid.add(statusText, 0, row, 1, 1);
		}
		if (false) {
			row++;
			// in case of pushing showDetailsButton
			Text oneRefereeText = new Text("One referee text");
			grid.add(oneRefereeText, 0, row, 5, 1);
		}
		if (false) {

			row++;
			// in case of pushing updateDetailsButton
			Text idText2 = new Text("ID");
			grid.add(idText2, 0, row, 1, 1);

			Text firstNameText2 = new Text("First name");
			grid.add(firstNameText2, 1, row, 1, 1);

			Text lastNameText2 = new Text("Last name");
			grid.add(lastNameText2, 2, row, 1, 1);

			Text allocationsText2 = new Text("Allocations");
			grid.add(allocationsText2, 3, row, 1, 1);

			row++;

			TextField idEdit2 = new TextField();
			grid.add(idEdit2, 0, row, 1, 1);

			TextField firstNameEdit2 = new TextField();
			grid.add(firstNameEdit2, 1, row, 1, 1);

			TextField lastNameEdit2 = new TextField();
			grid.add(lastNameEdit2, 2, row, 1, 1);

			TextField allocationsEdit2 = new TextField();
			grid.add(allocationsEdit2, 3, row, 1, 1);

			row++;

			Text qualificationText2 = new Text("Qualification");
			grid.add(qualificationText2, 0, row, 1, 1);

			Text homeAreaText2 = new Text("Home area");
			grid.add(homeAreaText2, 1, row, 1, 1);

			Text travelsToText2 = new Text("Travels to");
			grid.add(travelsToText2, 2, row, 1, 1);

			row++;

			ChoiceBox<String> qualificationList2 = new ChoiceBox<>();
			qualificationList2.getItems().addAll("NJB1", "NJB2", "NJB3",
					"NJB4", "IJB1", "IJB2", "IJB3", "IJB4");
			grid.add(qualificationList2, 0, row, 1, 1);

			ChoiceBox<String> homeAreaList2 = new ChoiceBox<>();
			homeAreaList2.getItems().addAll("North", "Central", "South");
			grid.add(homeAreaList2, 1, row, 1, 1);

			ChoiceBox<String> travelsToList2 = new ChoiceBox<>();
			travelsToList2.getItems().addAll("YNN", "NYN", "NNY", "YYN", "YNY",
					"NYY", "YYY");
			grid.add(travelsToList2, 2, row, 1, 1);

			Button updateButton2 = new Button();
			updateButton2.setText("Update");
			grid.add(updateButton2, 3, row, 1, 1);
		}

		if (false) {

			row++;
			// in case of pushing addRefereeButton
			Text idText3 = new Text("ID");
			grid.add(idText3, 0, row, 1, 1);

			Text firstNameText3 = new Text("First name");
			grid.add(firstNameText3, 1, row, 1, 1);

			Text lastNameText3 = new Text("Last name");
			grid.add(lastNameText3, 2, row, 1, 1);

			Text allocationsText3 = new Text("Allocations");
			grid.add(allocationsText3, 3, row, 1, 1);

			row++;

			TextField idEdit3 = new TextField();
			grid.add(idEdit3, 0, row, 1, 1);

			TextField firstNameEdit3 = new TextField();
			grid.add(firstNameEdit3, 1, row, 1, 1);

			TextField lastNameEdit3 = new TextField();
			grid.add(lastNameEdit3, 2, row, 1, 1);

			TextField allocationsEdit3 = new TextField();
			grid.add(allocationsEdit3, 3, row, 1, 1);

			row++;

			Text qualificationText3 = new Text("Qualification");
			grid.add(qualificationText3, 0, row, 1, 1);

			Text homeAreaText3 = new Text("Home area");
			grid.add(homeAreaText3, 1, row, 1, 1);

			Text travelsToText3 = new Text("Travels to");
			grid.add(travelsToText3, 2, row, 1, 1);

			row++;

			ChoiceBox<String> qualificationList3 = new ChoiceBox<>();
			qualificationList3.getItems().addAll("NJB1", "NJB2", "NJB3",
					"NJB4", "IJB1", "IJB2", "IJB3", "IJB4");
			grid.add(qualificationList3, 0, row, 1, 1);

			ChoiceBox<String> homeAreaList3 = new ChoiceBox<>();
			homeAreaList3.getItems().addAll("North", "Central", "South");
			grid.add(homeAreaList3, 1, row, 1, 1);

			ChoiceBox<String> travelsToList3 = new ChoiceBox<>();
			travelsToList3.getItems().addAll("YNN", "NYN", "NNY", "YYN", "YNY",
					"NYY", "YYY");
			grid.add(travelsToList3, 2, row, 1, 1);

			Button addButton3 = new Button();
			addButton3.setText("Add");
			grid.add(addButton3, 3, row, 1, 1);
		}
		if (false) {
			CategoryAxis xAxis = new CategoryAxis();
			xAxis.setLabel("Referees");

			NumberAxis yAxis = new NumberAxis();
			yAxis.setLabel("Allocations");

			BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);

			XYChart.Series<String, Number> dataSeries1 = new XYChart.Series<>();

			dataSeries1.getData().add(new XYChart.Data<>("AB1", 5));
			dataSeries1.getData().add(new XYChart.Data<>("BC2", 6));
			dataSeries1.getData().add(new XYChart.Data<>("CD3", 7));

			barChart.getData().add(dataSeries1);
			barChart.setLegendVisible(false);
			// https://stackoverflow.com/questions/15237192/how-to-display-bar-value-on-top-of-bar-javafx
			// (TODO)
			row++;
			grid.add(barChart, 0, row, 5, 5);
		}
		if (false) {
			Text step2of2 = new Text("Step 2 of 2 - Referees allocations");
			grid.add(step2of2, 0, row, 3, 1);

			Button doneButton = new Button();
			doneButton.setText("Done");
			grid.add(doneButton, 3, row, 1, 1);

			Button exitButton2 = new Button();
			exitButton2.setText("Exit");
			grid.add(exitButton2, 4, row, 1, 1);

			row++;

			Text weekNumberText = new Text("Week number");
			grid.add(weekNumberText, 0, row, 1, 1);

			Text areaText = new Text("Area");
			grid.add(areaText, 1, row, 1, 1);

			Text matchLevelText = new Text("Match level");
			grid.add(matchLevelText, 2, row, 1, 1);

			row++;

			ChoiceBox<Integer> weekNumberList = new ChoiceBox<>();
			weekNumberList.getItems().addAll(1, 2, 3, 4, 5, 6, 7, 8);
			grid.add(weekNumberList, 0, row, 1, 1);

			ChoiceBox<String> areaList = new ChoiceBox<>();
			areaList.getItems().addAll("North", "Central", "South");
			grid.add(areaList, 1, row, 1, 1);

			ChoiceBox<String> matchLevelList = new ChoiceBox<>();
			matchLevelList.getItems().addAll("Junior", "Senior");
			grid.add(matchLevelList, 2, row, 1, 1);

			Button allocateRefereesButton = new Button();
			allocateRefereesButton.setText("Allocate referees");
			grid.add(allocateRefereesButton, 3, row, 1, 1);

			row++;

			Text chosenRefereesText = new Text("Chosen referees");
			grid.add(chosenRefereesText, 0, row, 1, 1);

			row++;

			TextArea chosenRefereesTextArea = new TextArea();
			chosenRefereesTextArea.setPrefRowCount(2);
			grid.add(chosenRefereesTextArea, 0, row, 5, 2);

			row += 2;

			Text allSuitableRefereesText = new Text("All suitable referees");
			grid.add(allSuitableRefereesText, 0, row, 1, 1);

			row++;

			TextArea allSuitableRefereesTextArea = new TextArea();
			allSuitableRefereesTextArea.setPrefRowCount(12);
			grid.add(allSuitableRefereesTextArea, 0, row, 5, 5);

			row += 5;

			Text statusText2 = new Text("Status");
			grid.add(statusText2, 0, row, 1, 1);
		}

		Scene scene = new Scene(grid, 900, 700);

		primaryStage.setTitle("CS Team Project");
		primaryStage.setScene(scene);
		primaryStage.show();

	}

	public static void main(String[] args) {
		Referee[] r = Referee.read("RefereesIn.txt");
		Referee.write("RefereesOut.txt", r);
		// launch(args);
	}
}