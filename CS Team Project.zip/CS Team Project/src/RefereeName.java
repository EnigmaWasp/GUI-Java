public class RefereeName {

	final String firstName;

	final String lastName;

	RefereeName(final String firstName, final String lastName) {
		checkName(firstName);
		checkName(lastName);
		this.firstName = firstName;
		this.lastName = lastName;
	}

	static void checkName(String name) {
		if (name.length() == 0) {
			throw new IllegalArgumentException("name is empty");
		}
		if (name.charAt(0) < 'A' || name.charAt(0) > 'Z') {
			throw new IllegalArgumentException("first letter is not uppercase");
		}
		for (int i = 0; i < name.length(); i++) {
			char c = name.charAt(i);
			if (!('a' <= c && c <= 'z' || 'A' <= c && c <= 'Z' || c == '-')) {
				throw new IllegalArgumentException("invalid character " + c);
			}

		}
		if (name.charAt(name.length() - 1) == '-') {
			throw new IllegalArgumentException("last character is -");
		}
	}

	@Override
	public String toString() {
		return firstName + " " + lastName;
	}

	String getInitials() {
		return "" + firstName.charAt(0) + lastName.charAt(0);
	}
}
