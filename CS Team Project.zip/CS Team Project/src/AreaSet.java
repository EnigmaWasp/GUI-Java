public class AreaSet {

	final boolean North;

	final boolean Central;

	final boolean South;

	AreaSet(final boolean North, final boolean Central, final boolean South) {
		this.North = North;
		this.Central = Central;
		this.South = South;
	}

	static AreaSet parse(String s) {
		if (!(s.length() == 3 && (s.charAt(0) == 'Y' || s.charAt(0) == 'N')
				&& (s.charAt(1) == 'Y' || s.charAt(1) == 'N') && (s.charAt(2) == 'Y' || s
				.charAt(2) == 'N'))) {
			throw new IllegalArgumentException(s);
		}
		return new AreaSet(s.charAt(0) == 'Y', s.charAt(1) == 'Y',
				s.charAt(2) == 'Y');
	}

	@Override
	public String toString() {
		return "" + (North ? 'Y' : 'N') + (Central ? 'Y' : 'N')
				+ (South ? 'Y' : 'N');
	}

	boolean contains(Area a) {
		if (a == Area.North) {
			return North;
		}
		if (a == Area.South) {
			return South;
		}
		if (a == Area.Central) {
			return Central;
		}
		return false;
	}
}
