public class QualificationLevel {

	final int level;

	QualificationLevel(final int level) {
		if (level < 1 || level > 4) {
			throw new IllegalArgumentException("" + level);
		}
		this.level = level;
	}

	@Override
	public String toString() {
		return "" + level;
	}
}
