public class Qualification {

	final QualificationAwardingBody body;

	final QualificationLevel level;

	Qualification(final QualificationAwardingBody body,
			final QualificationLevel level) {
		this.body = body;
		this.level = level;
	}

	static Qualification parse(String s) {
		return new Qualification(QualificationAwardingBody.valueOf(s.substring(
				0, 3)),
				new QualificationLevel(Integer.parseInt(s.substring(3))));
	}

	@Override
	public String toString() {
		return "" + body + level;
	}
}
