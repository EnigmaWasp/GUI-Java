public class RefereeId implements Comparable<RefereeId> {

	final String initials;

	final int number;

	RefereeId(final String initials, final int number) {
		if (initials.length() != 2 || initials.charAt(0) < 'A'
				|| initials.charAt(0) > 'Z' || initials.charAt(1) < 'A'
				|| initials.charAt(1) > 'Z' || number <= 0) {
			throw new IllegalArgumentException(initials + " " + number);
		}
		this.initials = initials;
		this.number = number;
	}

	@Override
	public int compareTo(RefereeId second) {
		int cmp = this.initials.compareTo(second.initials);
		if (cmp != 0) {
			return cmp;
		}
		return Integer.compare(this.number, second.number);
	}

	static RefereeId parse(String s) {
		return new RefereeId(s.substring(0, 2),
				Integer.parseInt(s.substring(2)));
	}

	@Override
	public String toString() {
		return initials + number;
	}
}
