public enum Area {
	North, Central, South;
	int distanceTo(Area second) {
		if (this == second) {
			return 0;
		} else if (this == North && second == South || second == North
				&& this == South) {
			return 2;
		} else {
			return 1;
		}
	}
}
