public enum QualificationAwardingBody {
	NJB, IJB
}
