import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOError;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Referee {

	final RefereeId id;

	final RefereeName name;

	final Qualification qual;

	final int allocations;

	final Area home;

	final AreaSet travelsTo;

	Referee(final RefereeId id, final RefereeName name,
			final Qualification qual, final int allocations, final Area home,
			final AreaSet travelsTo) {
		if (name.getInitials().compareTo(id.initials) != 0) {
			throw new IllegalArgumentException(
					"mismatch of name and initials of referee " + id + " "
							+ name);
		}
		if (allocations < 0) {
			throw new IllegalArgumentException(
					"the number of matches allocations is negative for referee "
							+ name);
		}
		if (allocations > 52) {
			throw new IllegalArgumentException(
					"too many allocations for referee " + name);
		}
		if (!travelsTo.contains(home)) {
			throw new IllegalArgumentException(
					"home doesn't belong to areas that the candidate is willing to travel to for referee "
							+ name);
		}
		this.id = id;
		this.name = name;
		this.qual = qual;
		this.allocations = allocations;
		this.home = home;
		this.travelsTo = travelsTo;
	}

	static Referee parse(String s) {
		s = s.trim();
		String[] parts = s.split("\\s+");
		if (parts.length != 7) {
			throw new IllegalArgumentException(s);
		}
		return new Referee(RefereeId.parse(parts[0]), new RefereeName(parts[1],
				parts[2]), Qualification.parse(parts[3]),
				Integer.parseInt(parts[4]), Area.valueOf(parts[5]),
				AreaSet.parse(parts[6]));
	}

	@Override
	public String toString() {
		return "" + id + " " + name + " " + qual + " " + allocations + " "
				+ home + " " + travelsTo;
	}

	static Referee[] read(String fileName) {
		List<Referee> r = new ArrayList<>();
		try (Scanner in = new Scanner(new File(fileName))) {
			while (in.hasNextLine()) {
				r.add(Referee.parse(in.nextLine()));
			}

		} catch (FileNotFoundException e) {
			throw new IOError(e);
		}
		return r.toArray(new Referee[0]);
	}

	static void write(String fileName, Referee[] rs) {
		try (PrintWriter out = new PrintWriter(fileName)) {
			for (Referee r : rs) {
				out.println(r);
			}
		} catch (FileNotFoundException e) {
			throw new IOError(e);
		}
	}
}